;(function($){

  $(document).on('paste', 'div[contenteditable="true"]', function(e){
		let text = (e.originalEvent || e).clipboardData;
		if(!text){
			text = window.clipboardData.getData('text') || '';
			if(text !== '' && text.match(/^https?:\/\/[\-A-Za-z0-9+&@#\/%?=~_|!:,.;]+[\-A-Za-z0-9+&@#\/%=~_|]/)){
				e.preventDefault();
				text = text.replace(/</g, '&lt;').replace(/>/g, '&gt;');
				if(window.getSelection){
					let newNode = document.createElement('a');
					newNode.innerText = text;
					newNode.href = text;
					window.getSelection().getRangeAt(0).insertNode(newNode);
				}else{
					document.section.createRange().pasteHTML('<a href="'+text+'">'+text+'</a>');
				}
			}
		}else{
			text = text.getData('text/plain') || '';
			if(text !== '' && text.match(/^https?:\/\/[\-A-Za-z0-9+&@#\/%?=~_|!:,.;]+[\-A-Za-z0-9+&@#\/%=~_|]/)){
				e.preventDefault();
				text = text.replace(/</g, '&lt;').replace(/>/g, '&gt;');
				document.execCommand('insertHTML', false, '<a href="'+text+'">'+text+'</a>');
			}
		}
	});

})(jQuery);
