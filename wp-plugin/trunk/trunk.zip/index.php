<?php
// Silence is golden

// But sometimes invisible is better...
http_response_code(404);
die('404 Not Found');
